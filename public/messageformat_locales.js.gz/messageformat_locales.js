MessageFormat.locale.de=function(n){return n===1?"one":"other"}
MessageFormat.locale.en=function(n){return n===1?"one":"other"}
MessageFormat.locale.es=function(n){return n===1?"one":"other"}
MessageFormat.locale.fr=function(n){return n===0||n==1?"one":"other"}
MessageFormat.locale.ja=function(n){return "other"}
MessageFormat.locale.ko=function(n){return "other"}
MessageFormat.locale.pt=function(n){return n===1?"one":"other"}
MessageFormat.locale.zh=function(n){return "other"}